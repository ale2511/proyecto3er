function iniciarSesion() {
    const nombre = document.getElementById("nombre").value.trim();
    const email = document.getElementById("email").value.trim();
    const contrasena = document.getElementById("contrasena").value;

    const nombreValido = "Carlos";
    const emailValido = "carlos@gmail.com";
    const contrasenaValida = "carlitos123";

    if (
        nombre === nombreValido &&
        email === emailValido &&
        contrasena === contrasenaValida
    ) {
        alert("Inicio de sesión exitoso. ¡Bienvenido Carlos!");
        // Redirige a otra página si quieres
        window.location.href = "iniciado.html"
        return false; // Previene el envío del formulario
    } else {
        alert("Datos incorrectos. Intenta nuevamente.");
        return false; // Previene el envío del formulario
    }
}
