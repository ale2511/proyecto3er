function registrarse() {
    const nombre = document.getElementById("nombre").value.trim();
    const email = document.getElementById("email").value.trim();
    const contrasena = document.getElementById("password").value;
    const confirmar = document.getElementById("cPassword").value;

    const nombreValido = "Carlos";
    const emailValido = "carlos@gmail.com";
    const contrasenaValida = "carlitos123";

    if (
        nombre === nombreValido &&
        email === emailValido &&
        contrasena === contrasenaValida &&
        confirmar === contrasenaValida
    ) {
        alert("Registro exitoso. ¡Bienvenido Carlos!");
        window.location.href = "iniciado.html";
        return false;
    } else {
        alert("Datos inválidos. Solo Carlos puede registrarse.");
        return false;
    }
}